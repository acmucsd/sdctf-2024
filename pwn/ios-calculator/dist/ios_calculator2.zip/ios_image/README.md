# iOS Calculator 2

To run the emulator,

```
/usr/local/bin/qemu-system-aarch64 \
-M d22-idevice,kernelcache='/ios_image/kcache.patched',devicetree='/ios_image/dtre',ramdisk='/ios_image/rdsk',bootargs="cpus=1 rd=md0 serial=2",ram-size=524288000 \
-d unimp,int -cpu max -serial mon:stdio -nographic -monitor /dev/null -D /dev/null
```
